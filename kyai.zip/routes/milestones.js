const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/', (req, res) => {
  const milestones = db.prepare('SELECT * FROM milestones ORDER BY created_at ASC').all();
  res.json(milestones);
});

router.patch('/:id', (req, res) => {
  const { progress } = req.body;
  db.prepare('UPDATE milestones SET progress = ? WHERE id = ?').run(progress, req.params.id);
  res.json({ success: true });
});

module.exports = router;
